# Screenshots — MANDATORY, NOT YET CAPTURED

Screenshots could not be produced by the tooling that built this package. **Capture them yourself**
from a real terminal (show the command, the output, and the full window) and save as PNG here.
Do not substitute generated images.

| # | Evidence (from the task) | Command to run (repo root) | Suggested filename |
|---|---|---|---|
| 1 | circuit construction | `python phase5_hardware/hardware_manifest.py` (shows depth/gate tables) | `01_circuit_construction.png` |
| 2 | algorithm execution | `python phase3_domains/domain_usecases.py MARINE` | `02_algorithm_execution.png` |
| 3 | simulation | `python phase1_learning/learning_experiments.py` | `03_simulation_phase1.png` |
| 4 | test results | `pytest phase6_testing algorithm_lab -v` | `04_test_results.png` |
| 5 | domain workload | `python phase3_domains/domain_usecases.py` (all five domains) | `05_domain_workload.png` |
| 6 | network execution | `python phase6_testing/test_qnet_workload.py` and `python phase4_network/qnet_physics.py` | `06_network_execution.png` |
| 7 | runtime/API execution | Marine runtime API (NOT part of this package) — capture from the deployed service | `07_runtime_api.png` |
| 8 | failure handling | `pytest phase6_testing/test_qnet_workload.py -v` (fault scenarios) | `08_failure_handling.png` |
| 9 | hardware execution | **N/A until hardware access exists** — do not fabricate | — |
