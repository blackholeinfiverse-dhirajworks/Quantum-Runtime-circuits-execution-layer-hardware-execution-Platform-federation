"""
domain_usecases.py -- Phase 3 "Domain Formulation" templates (SYNTHETIC DATA).

Ownership note: domain quantum applications belong to Ganesh and data to the domain teams.
These are runnable templates on invented, seeded data so the formulation -> baseline ->
QAOA -> evaluation pipeline exists and can be re-pointed at real data. NOTHING here is a
statement about real forests, cities, farms, rivers or ports.

Evaluation is in the DOMAIN's objective (not just QUBO energy), against:
  * exact optimum (brute force),
  * random search given the SAME shot budget (the baseline QAOA must beat to mean anything),
  * for Bharat Mala, the surrogate-vs-true-objective gap is reported separately from QAOA's.
No quantum-advantage claim: every instance (<= 12 qubits) is solved exactly by brute force.
"""
from __future__ import annotations

import itertools
import json
import math
import os
import sys
from dataclasses import dataclass, field
from typing import Callable, Dict

import numpy as np
from scipy.optimize import minimize
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator

SEED, SHOTS, P_LAYERS, N_STARTS = 42, 4096, 2, 4


@dataclass
class Problem:
    key: str
    domain: str
    description: str
    n: int
    n_dec: int
    linear: np.ndarray
    quad: Dict[tuple, float]
    constant: float
    feasible: Callable
    objective: Callable
    sense: str
    decode: Callable
    meta: dict = field(default_factory=dict)


class QuboBuilder:
    def __init__(self, n):
        self.n, self.lin, self.quad, self.const = n, np.zeros(n), {}, 0.0

    def add_lin(self, i, c): self.lin[i] += c

    def add_quad(self, i, j, c):
        if i == j: self.lin[i] += c
        else:
            k = (min(i, j), max(i, j)); self.quad[k] = self.quad.get(k, 0.0) + c

    def add_square(self, coeffs, target, weight):          # weight * (sum a_i x_i - target)^2
        items = list(coeffs.items())
        for i, a in items: self.add_quad(i, i, weight * (a * a - 2 * target * a))
        for (i, a), (j, b) in itertools.combinations(items, 2): self.add_quad(i, j, 2 * weight * a * b)
        self.const += weight * target * target


def bits_of(idx, n): return tuple((idx >> i) & 1 for i in range(n))


def energies(p):
    idx = np.arange(2 ** p.n)
    bits = ((idx[:, None] >> np.arange(p.n)) & 1).astype(float)
    E = bits @ p.linear + p.constant
    for (i, j), c in p.quad.items(): E += c * bits[:, i] * bits[:, j]
    return E


def qubo_to_ising(p):
    h = np.zeros(p.n); J = {}; off = p.constant
    for i in range(p.n): off += p.linear[i] / 2; h[i] -= p.linear[i] / 2
    for (i, j), q in p.quad.items():
        off += q / 4; h[i] -= q / 4; h[j] -= q / 4; J[(i, j)] = q / 4
    return h, J, off


def apply_mixer(psi, beta, n):
    c, s = math.cos(beta), -1j * math.sin(beta)
    for q in range(n):
        v = psi.reshape(2 ** (n - q - 1), 2, 2 ** q)
        a, b = v[:, 0, :].copy(), v[:, 1, :].copy()
        v[:, 0, :] = c * a + s * b; v[:, 1, :] = s * a + c * b
        psi = v.reshape(-1)
    return psi


def qaoa_state(Es, gammas, betas, n):
    psi = np.full(2 ** n, 1 / math.sqrt(2 ** n), dtype=complex)
    for g, b in zip(gammas, betas):
        psi = apply_mixer(psi * np.exp(-1j * g * Es), b, n)
    return psi


def optimise(Es, E_raw, n, p=P_LAYERS, starts=N_STARTS, seed=SEED):
    rng = np.random.default_rng(seed); best = None
    for _ in range(starts):
        x0 = np.concatenate([rng.uniform(0, 1.0, p), rng.uniform(0, math.pi / 2, p)])
        f = lambda x: float(np.real(np.sum(np.abs(qaoa_state(Es, x[:p], x[p:], n)) ** 2 * E_raw)))
        r = minimize(f, x0, method="COBYLA", options={"maxiter": 300, "rhobeg": 0.3})
        if best is None or r.fun < best.fun: best = r
    return best


def build_circuit(p, scale, gammas, betas, measure=False):
    h, J, _ = qubo_to_ising(p)
    qc = QuantumCircuit(p.n, p.n if measure else 0)
    qc.h(range(p.n))
    for g, b in zip(gammas, betas):
        for (i, j), Jij in J.items(): qc.rzz(2 * g * scale * Jij, i, j)
        for i in range(p.n): qc.rz(2 * g * scale * h[i], i)
        qc.rx(2 * b, range(p.n))
    if measure: qc.measure(range(p.n), range(p.n))
    return qc


# ------------------------------------------------------------------ problems
def vana_fire_risk(seed=SEED):
    rng = np.random.default_rng(seed); n_s = 8
    risk = np.round(rng.uniform(0.2, 1.0, n_s), 2); cost = rng.integers(1, 6, n_s)
    B = int(0.5 * cost.sum()); m = math.ceil(math.log2(B + 1)); n = n_s + m
    qb = QuboBuilder(n)
    for i in range(n_s): qb.add_lin(i, -risk[i])
    P = 1.5 * risk.max()
    co = {i: float(cost[i]) for i in range(n_s)}; co.update({n_s + k: float(2 ** k) for k in range(m)})
    qb.add_square(co, B, P)
    feas = lambda x: sum(cost[i] * x[i] for i in range(n_s)) <= B
    obj = lambda x: float(sum(risk[i] * x[i] for i in range(n_s)))
    dec = lambda x: {"protected_sectors": [i for i in range(n_s) if x[i]], "risk_covered": round(obj(x), 3),
                     "crew_days_used": int(sum(cost[i] * x[i] for i in range(n_s))), "budget": B}
    return Problem("VANA", "VANA — forest intelligence",
                   "Fire-risk resource prioritisation: choose sectors to protect within a crew-day "
                   "budget, maximising risk covered (knapsack, <= via slack bits).",
                   n, n_s, qb.lin, qb.quad, qb.const, feas, obj, "max", dec,
                   {"risk": risk.tolist(), "crew_cost": cost.tolist(), "budget": B, "slack_bits": m, "penalty": P})


def ucics_housing(seed=SEED):
    rng = np.random.default_rng(seed + 1); side = 3; n = side * side
    value = np.round(rng.uniform(1.0, 5.0, n), 2)
    adj = [(r * side + c, r * side + c + 1) for r in range(side) for c in range(side - 1)] + \
          [(r * side + c, (r + 1) * side + c) for r in range(side - 1) for c in range(side)]
    P = 1.5 * value.max(); qb = QuboBuilder(n)
    for i in range(n): qb.add_lin(i, -value[i])
    for i, j in adj: qb.add_quad(i, j, P)
    feas = lambda x: all(not (x[i] and x[j]) for i, j in adj)
    obj = lambda x: float(sum(value[i] * x[i] for i in range(n)))
    dec = lambda x: {"developed_parcels": [i for i in range(n) if x[i]], "housing_value": round(obj(x), 3),
                     "adjacent_conflicts": sum(1 for i, j in adj if x[i] and x[j])}
    return Problem("UCICS", "UCICS — urban planning & housing",
                   "Land-use allocation: develop parcels on a 3x3 grid maximising housing value with no "
                   "two adjacent developed parcels (maximum-weight independent set).",
                   n, n, qb.lin, qb.quad, qb.const, feas, obj, "max", dec,
                   {"parcel_value": value.tolist(), "adjacent_pairs": adj, "penalty": P})


def aiaic_crops(seed=SEED):
    rng = np.random.default_rng(seed + 2); n_c = 8
    profit = np.round(rng.uniform(2.0, 9.0, n_c), 2); water = rng.integers(1, 6, n_c)
    W = int(0.5 * water.sum()); m = math.ceil(math.log2(W + 1))
    pairs = [(i, j) for i, j in itertools.combinations(range(n_c), 2) if rng.random() < 0.25]
    conflict = {pr: round(float(rng.uniform(1.0, 4.0)), 2) for pr in pairs}
    n = n_c + m; qb = QuboBuilder(n)
    for i in range(n_c): qb.add_lin(i, -profit[i])
    for (i, j), c in conflict.items(): qb.add_quad(i, j, +c)
    P = 1.5 * profit.max()
    co = {i: float(water[i]) for i in range(n_c)}; co.update({n_c + k: float(2 ** k) for k in range(m)})
    qb.add_square(co, W, P)
    feas = lambda x: sum(water[i] * x[i] for i in range(n_c)) <= W
    obj = lambda x: float(sum(profit[i] * x[i] for i in range(n_c))
                          - sum(c for (i, j), c in conflict.items() if x[i] and x[j]))
    dec = lambda x: {"crops_planted": [i for i in range(n_c) if x[i]], "net_profit": round(obj(x), 3),
                     "water_used": int(sum(water[i] * x[i] for i in range(n_c))), "water_budget": W}
    return Problem("AIAIC", "AIAIC — agricultural intelligence",
                   "Crop/resource allocation: choose crops under a water budget with rotation-conflict "
                   "penalties, maximising net profit (quadratic knapsack).",
                   n, n_c, qb.lin, qb.quad, qb.const, feas, obj, "max", dec,
                   {"profit": profit.tolist(), "water": water.tolist(), "budget": W,
                    "conflicts": {f"{i}-{j}": c for (i, j), c in conflict.items()},
                    "slack_bits": m, "penalty": P})


def bharat_mala_hubs(seed=SEED):
    """K=3 hubs among 10 river ports (p-median). QUBO is a SURROGATE (dispersion + closeness);
    the true p-median cost is used for evaluation."""
    rng = np.random.default_rng(seed + 3); n, K = 10, 3
    chain = np.sort(rng.uniform(0, 100, n)); lateral = rng.normal(0, 6, n)
    pos = np.stack([chain, lateral], axis=1)
    D = np.hypot(pos[:, None, 0] - pos[None, :, 0], pos[:, None, 1] - pos[None, :, 1])
    demand = np.round(rng.uniform(1, 10, n), 1)
    closeness = np.array([sum(demand[j] / (1 + D[i, j]) for j in range(n)) for i in range(n)])
    a = closeness / closeness.max(); ell, lam, P = 25.0, 0.35, 1.0
    qb = QuboBuilder(n)
    for i in range(n): qb.add_lin(i, -a[i])
    for i, j in itertools.combinations(range(n), 2): qb.add_quad(i, j, lam * math.exp(-D[i, j] / ell))
    qb.add_square({i: 1.0 for i in range(n)}, K, P)
    feas = lambda x: sum(x) == K

    def cost(x):
        hubs = [i for i in range(n) if x[i]]
        return float(sum(demand[j] * min(D[j, h] for h in hubs) for j in range(n)))
    dec = lambda x: {"hubs": [i for i in range(n) if x[i]],
                     "demand_weighted_transport_cost": round(cost(x), 2) if sum(x) else None}
    return Problem("BHARAT_MALA", "Bharat Mala — river intelligence",
                   "Hub-and-spoke: choose 3 of 10 river ports as hubs minimising demand-weighted distance "
                   "to the nearest hub (p-median); QUBO is a dispersion surrogate.",
                   n, n, qb.lin, qb.quad, qb.const, feas, cost, "min", dec,
                   {"demand": demand.tolist(), "K": K, "surrogate": True,
                    "surrogate_note": "QUBO = -closeness + lambda*overlap + (sum x - K)^2"})


def marine_vessel_routing(seed=SEED):
    """Marine Intelligence: survey-vessel routing. Base port 0 + 3 waypoints; visit each waypoint once and
    return, minimising distance. One-hot encoding x[c][t] (city c in 1..3 at position t in 1..3) -> 9 qubits.
    Constraints (each waypoint once, each position once) are QUBO penalties."""
    rng = np.random.default_rng(seed + 4)
    pts = np.vstack([[10.0, 10.0], rng.uniform(20, 95, (3, 2))])          # km, synthetic sea area
    d = np.hypot(pts[:, None, 0] - pts[None, :, 0], pts[:, None, 1] - pts[None, :, 1])
    var = lambda c, t: (c - 1) * 3 + (t - 1)
    n = 9; qb = QuboBuilder(n); P = 2.5 * float(d.max())
    for t in (1, 2):
        for c in (1, 2, 3):
            for c2 in (1, 2, 3):
                if c != c2: qb.add_quad(var(c, t), var(c2, t + 1), d[c][c2])
    for c in (1, 2, 3):
        qb.add_lin(var(c, 1), d[0][c]); qb.add_lin(var(c, 3), d[c][0])
        qb.add_square({var(c, t): 1.0 for t in (1, 2, 3)}, 1, P)
    for t in (1, 2, 3):
        qb.add_square({var(c, t): 1.0 for c in (1, 2, 3)}, 1, P)

    def perm(x):
        m = np.array(x).reshape(3, 3)                                      # rows = city, cols = position
        if not (all(m.sum(axis=1) == 1) and all(m.sum(axis=0) == 1)): return None
        return [int(np.argmax(m[:, t])) + 1 for t in range(3)]             # city at each position

    feas = lambda x: perm(x) is not None

    def length(x):
        o = perm(x); route = [0] + o + [0]
        return float(sum(d[route[i]][route[i + 1]] for i in range(4)))
    dec = lambda x: {"route": ([0] + perm(x) + [0]) if perm(x) else None,
                     "tour_length_km": round(length(x), 3) if perm(x) else None}
    return Problem("MARINE", "Marine Intelligence — vessel routing",
                   "Survey-vessel routing: base port + 3 waypoints, shortest closed tour (one-hot TSP, 9 qubits).",
                   n, n, qb.lin, qb.quad, qb.const, feas, length, "min", dec,
                   {"coordinates_km": pts.round(2).tolist(), "penalty": P, "distinct_feasible_tours": 6,
                    "note": "symmetric distances: 6 permutations = 3 distinct tours (each counted in both directions)"})


# ------------------------------------------------------------------ evaluation
def evaluate(p):
    n = p.n; E = energies(p); N = 2 ** n
    qubo_idx = int(np.argmin(E)); qubo_bits = bits_of(qubo_idx, n)
    feas_list = [(b, p.objective(b)) for b in (bits_of(i, p.n_dec) for i in range(2 ** p.n_dec)) if p.feasible(b)]
    pick = max if p.sense == "max" else min
    true_bits, true_obj = pick(feas_list, key=lambda t: t[1])
    qubo_feasible = p.feasible(qubo_bits[:p.n_dec])
    qubo_obj = p.objective(qubo_bits[:p.n_dec]) if qubo_feasible else None

    scale = math.pi / float(np.ptp(E)); Es = E * scale
    res = optimise(Es, E, n)
    gammas, betas = res.x[:P_LAYERS], res.x[P_LAYERS:]
    probs = np.abs(qaoa_state(Es, gammas, betas, n)) ** 2

    h, J, off = qubo_to_ising(p)                         # validate QUBO -> Ising -> circuit
    for idx in np.random.default_rng(0).integers(0, N, 64):
        z = [1 - 2 * v for v in bits_of(int(idx), n)]
        e_is = off + sum(h[i] * z[i] for i in range(n)) + sum(c * z[i] * z[j] for (i, j), c in J.items())
        assert abs(e_is - E[idx]) < 1e-9, "QUBO/Ising mismatch"
    qc = build_circuit(p, scale, gammas, betas)
    circuit_match = float(np.max(np.abs(Statevector.from_instruction(qc).probabilities() - probs)))
    assert circuit_match < 1e-8, f"circuit != numpy sim ({circuit_match})"

    qm = build_circuit(p, scale, gammas, betas, measure=True)
    sim = AerSimulator(seed_simulator=SEED); tq = transpile(qm, sim, seed_transpiler=SEED)
    counts = sim.run(tq, shots=SHOTS, seed_simulator=SEED).result().get_counts()
    sampled = [(tuple(int(ch) for ch in reversed(bs.replace(" ", ""))), c) for bs, c in counts.items()]
    feas_s = [(b[:p.n_dec], c) for b, c in sampled if p.feasible(b[:p.n_dec])]
    best_q = pick(feas_s, key=lambda t: p.objective(t[0])) if feas_s else None
    shots_feasible = sum(c for _, c in feas_s) / SHOTS

    rng = np.random.default_rng(SEED + 99); rnd = rng.integers(0, N, SHOTS)
    rf = [bits_of(int(i), n)[:p.n_dec] for i in rnd if p.feasible(bits_of(int(i), n)[:p.n_dec])]
    best_r = pick(rf, key=p.objective) if rf else None

    gap = lambda b: None if b is None else round(abs(p.objective(b) - true_obj) / abs(true_obj), 6)
    feas_mask = np.array([p.feasible(bits_of(i, n)[:p.n_dec]) for i in range(N)])
    p_opt = float(probs[qubo_idx])
    # exact (no sampling noise) probability that k i.i.d. shots contain the domain-optimal decision
    # vector: 1-(1-q)^k, q = QAOA mass on that decision vector (summed over slack bits);
    # random search has q0 = 2^-n_dec.
    dec_mask = np.array([bits_of(i, n)[:p.n_dec] == true_bits for i in range(N)])
    q_dec = float(probs[dec_mask].sum()); q0 = 2.0 ** -p.n_dec
    budget_curve = {str(k): {"qaoa": round(1 - (1 - q_dec) ** k, 4), "random_search": round(1 - (1 - q0) ** k, 4)}
                    for k in (8, 16, 32, 64, 128, 256, 1024, 4096)}
    return {
        "domain": p.domain, "description": p.description, "synthetic_data": True, "meta": p.meta,
        "qubits": n, "decision_variables": p.n_dec,
        "circuit": {"p_layers": P_LAYERS, "depth_transpiled_all_to_all": tq.depth(),
                    "qiskit_vs_numpy_max_prob_diff": circuit_match},
        "classical_exact": {"method": f"brute force over {2 ** p.n_dec} decision vectors",
                            "optimal_objective": round(true_obj, 4), "sense": p.sense,
                            "optimal_solution": p.decode(true_bits),
                            "qubo_ground_state_is_feasible": bool(qubo_feasible),
                            "qubo_ground_state_objective": None if qubo_obj is None else round(qubo_obj, 4),
                            "surrogate_gap_vs_true_optimum": None if qubo_obj is None else
                            round(abs(qubo_obj - true_obj) / abs(true_obj), 6)},
        "qaoa": {"optimiser": f"COBYLA, {N_STARTS} starts", "gammas": [round(float(x), 5) for x in gammas],
                 "betas": [round(float(x), 5) for x in betas], "expected_energy": round(float(res.fun), 5),
                 "energy_fraction_vs_uniform": round(float((np.sum(probs * E) - E.min()) / (E.mean() - E.min())), 4),
                 "prob_mass_on_qubo_ground_state": p_opt, "uniform_prob_of_ground_state": 1 / N,
                 "lift_over_uniform": round(p_opt * N, 2),
                 "prob_mass_on_feasible": round(float(probs[feas_mask].sum()), 4),
                 "uniform_prob_feasible": round(float(feas_mask.mean()), 4),
                 "shots": SHOTS, "shot_fraction_feasible": round(shots_feasible, 4),
                 "best_feasible_sampled": None if best_q is None else p.decode(best_q[0]),
                 "best_sampled_gap_to_true_optimum": None if best_q is None else gap(best_q[0]),
                 "best_sampled_shot_count": None if best_q is None else best_q[1]},
        "random_search_same_shots": {"shots": SHOTS, "feasible_fraction": round(len(rf) / SHOTS, 4),
                                     "best_feasible": None if best_r is None else p.decode(best_r),
                                     "gap_to_true_optimum": None if best_r is None else gap(best_r)},
        "shots_needed_to_find_optimum": {
            "qaoa_mass_on_optimal_decision_vector": q_dec, "random_mass": q0,
            "lift_over_random": round(q_dec / q0, 2),
            "P_find_optimum_within_k_shots": budget_curve,
            "note": "exact from the statevector (no sampling). At k=4096 both saturate because the "
                    "search space is <= 4096 states -- brute force is trivial at this size."},
        "uncertainty": {"readout_standard_error_of_feasible_fraction":
                        round(math.sqrt(shots_feasible * (1 - shots_feasible) / SHOTS), 5),
                        "note": "QAOA is a heuristic: single seed, statevector-optimised parameters, "
                                "shot-sampled readout; no confidence interval on optimality."},
    }


def main(keys=None):
    makers = {"VANA": vana_fire_risk, "UCICS": ucics_housing, "AIAIC": aiaic_crops,
              "BHARAT_MALA": bharat_mala_hubs,
              "MARINE": marine_vessel_routing}
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "domain_results.json")
    out = json.load(open(path)) if os.path.exists(path) else {}
    for k in (keys or makers):
        r = evaluate(makers[k]()); out[k] = r
        q, rs, ce = r["qaoa"], r["random_search_same_shots"], r["classical_exact"]
        print(f"{k:12s} qubits={r['qubits']:2d} optimum={ce['optimal_objective']:>8} | QAOA best gap="
              f"{q['best_sampled_gap_to_true_optimum']} feasible-mass={q['prob_mass_on_feasible']} "
              f"(uniform {q['uniform_prob_feasible']}) lift={q['lift_over_uniform']}x | random best gap="
              f"{rs['gap_to_true_optimum']}")
        with open(path, "w") as f: json.dump(out, f, indent=2, default=float)


if __name__ == "__main__":
    main(sys.argv[1:] or None)
