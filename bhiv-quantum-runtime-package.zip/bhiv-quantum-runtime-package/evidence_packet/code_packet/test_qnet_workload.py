"""
test_qnet_workload.py -- Phase 6 networking tests: node failure, communication failure,
inconsistent results, latency, duplicate messages, partial execution, replay reconstruction.

    pytest test_qnet_workload.py -v
    python test_qnet_workload.py        # also writes qnet_workload_evidence.json
"""
import json
import math
import os
import random
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "phase4_network"))
from qnet_workload import (NodeBehavior, SimTransport, run_workload, replay, verify_chain, sha,
                           SCHEMA_VERSION)

SHOTS = 4096


def run(behaviors, **kw):
    nodes = list(behaviors)
    return run_workload("ghz4", SHOTS, nodes, SimTransport(behaviors), **kw)


def kinds(log):
    out = {}
    for e in log.events: out[e["kind"]] = out.get(e["kind"], 0) + 1
    return out


def ok_nodes(n=3): return {f"n{i}": NodeBehavior() for i in range(n)}


def test_baseline_complete_and_matches_exact_distribution():
    res, log = run(ok_nodes())
    assert res["status"] == "COMPLETE" and res["shots_completed"] == SHOTS
    assert set(res["counts"]) <= {"0000", "1111"}
    sigma = math.sqrt(0.25 / SHOTS)
    assert abs(res["counts"]["0000"] / SHOTS - 0.5) <= 5 * sigma
    assert kinds(log).get("TIMEOUT", 0) == 0 and res["quarantined_nodes"] == []


def test_deterministic_same_inputs_same_hashes():
    a, la = run(ok_nodes()); b, lb = run(ok_nodes())
    assert a["aggregate_hash"] == b["aggregate_hash"] and a["events_head"] == b["events_head"]
    assert a["trace_id"] == b["trace_id"]


def test_node_failure_is_retried_on_another_node():
    beh = ok_nodes(); beh["n1"] = NodeBehavior(mode="down")
    res, log = run(beh)
    assert res["status"] == "COMPLETE" and res["shots_completed"] == SHOTS
    assert kinds(log).get("TIMEOUT", 0) >= 1


def test_single_flaky_link_message_drop_retried_with_same_invocation_id():
    beh = ok_nodes(); beh["n0"] = NodeBehavior(mode="drop_first_n", n=1)
    res, log = run(beh)
    assert res["status"] == "COMPLETE" and res["shots_completed"] == SHOTS
    disp = [e["data"] for e in log.events if e["kind"] == "DISPATCH" and e["data"]["shard"] == 0]
    assert len(disp) >= 2 and len({d["invocation_id"] for d in disp}) == 1      # idempotent retry


def test_transient_loss_on_every_link_exhausts_default_budget_and_is_disclosed_as_partial():
    """Documented policy limitation: each retry rotates to the NEXT node (it does not re-try the same
    node until the rotation wraps). If every node drops its first message, 3 attempts hit 3 distinct
    nodes that each drop once -> shard FAILS. The result must say PARTIAL, never COMPLETE."""
    beh = {f"n{i}": NodeBehavior(mode="drop_first_n", n=1) for i in range(3)}
    res, log = run(beh, max_attempts=3)
    assert res["status"] == "PARTIAL" and res["shots_completed"] == 0
    assert kinds(log)["SHARD_FAILED"] == 4


def test_transient_loss_on_every_link_recovers_with_one_extra_attempt():
    beh = {f"n{i}": NodeBehavior(mode="drop_first_n", n=1) for i in range(3)}
    res, log = run(beh, max_attempts=4)
    assert res["status"] == "COMPLETE" and res["shots_completed"] == SHOTS


def test_duplicate_messages_never_double_counted():
    beh = ok_nodes(); beh["n0"] = NodeBehavior(mode="duplicate")
    res, log = run(beh)
    assert res["shots_completed"] == SHOTS == sum(res["counts"].values())
    assert kinds(log).get("DUPLICATE_IGNORED", 0) >= 1


def test_inconsistent_physically_impossible_results_are_quarantined_and_rerun():
    beh = ok_nodes(); beh["n1"] = NodeBehavior(mode="corrupt_support")
    res, log = run(beh)
    assert res["status"] == "COMPLETE" and "n1" in res["quarantined_nodes"]
    assert set(res["counts"]) <= {"0000", "1111"}
    assert kinds(log)["VALIDATION_FAILED"] >= 1


def test_wrong_circuit_hash_is_rejected():
    beh = ok_nodes(); beh["n2"] = NodeBehavior(mode="wrong_circuit")
    res, log = run(beh)
    assert res["status"] == "COMPLETE" and "n2" in res["quarantined_nodes"]
    reasons = [e["data"]["reason"] for e in log.events if e["kind"] == "VALIDATION_FAILED"]
    assert any("circuit_hash" in r for r in reasons)


def test_latency_straggler_over_timeout_treated_as_timeout_and_bounded():
    beh = {"slow": NodeBehavior(latency_ms=150.0), "fast": NodeBehavior(latency_ms=10.0)}
    res, log = run(beh, timeout_ms=100.0, max_attempts=3)
    assert res["status"] == "COMPLETE"
    assert kinds(log).get("TIMEOUT", 0) >= 1
    assert res["virtual_completion_ms"] <= 3 * 100.0 + 10.0 + 1e-9


def test_partial_execution_is_disclosed_not_hidden():
    beh = {"good": NodeBehavior(), "dead": NodeBehavior(mode="down")}
    res, log = run(beh, max_attempts=1)
    assert res["status"] == "PARTIAL"
    assert 0 < res["shots_completed"] < SHOTS == res["shots_requested"]
    assert "PARTIAL" in res["uncertainty"]["note"]
    full = math.sqrt(0.25 / SHOTS)
    assert res["uncertainty"]["max_outcome_probability_standard_error"] > full


def test_total_outage_returns_partial_with_zero_shots_not_a_crash():
    res, _ = run({"a": NodeBehavior(mode="down"), "b": NodeBehavior(mode="down")})
    assert res["status"] == "PARTIAL" and res["shots_completed"] == 0 and res["counts"] == {}


def test_replay_reconstructs_same_aggregate_even_from_shuffled_log():
    beh = ok_nodes(); beh["n0"] = NodeBehavior(mode="duplicate"); beh["n1"] = NodeBehavior(mode="down")
    res, log = run(beh)
    r1 = replay(log.events)
    shuffled = list(log.events); random.Random(3).shuffle(shuffled)
    r2 = replay(shuffled)
    assert r1["aggregate_hash"] == r2["aggregate_hash"] == res["aggregate_hash"]
    assert res["replay_metadata"]["chain_verified"]


def test_tampered_log_fails_chain_verification():
    res, log = run(ok_nodes())
    evs = json.loads(json.dumps(log.events))
    for e in evs:
        if e["kind"] == "SHARD_ACCEPTED":
            e["data"]["counts"]["0000"] += 1; break
    assert not verify_chain(evs)
    with pytest.raises(ValueError):
        replay(evs)


def test_governance_fields_present_and_never_hardware():
    res, _ = run(ok_nodes())
    assert res["schema_version"] == SCHEMA_VERSION
    assert res["certification_state"] == "SIMULATOR_VERIFIED" and res["simulated_transport"] is True
    assert res["decision_authority"] == "NONE"
    assert res["uncertainty"]["max_outcome_probability_standard_error"] > 0


def build_evidence():
    scen = {
        "baseline": ok_nodes(),
        "node_down": {**ok_nodes(), "n1": NodeBehavior(mode="down")},
        "single_flaky_link_drop": {**ok_nodes(), "n0": NodeBehavior(mode="drop_first_n", n=1)},
        "duplicate_messages": {**ok_nodes(), "n0": NodeBehavior(mode="duplicate")},
        "corrupt_results": {**ok_nodes(), "n1": NodeBehavior(mode="corrupt_support")},
        "wrong_circuit": {**ok_nodes(), "n2": NodeBehavior(mode="wrong_circuit")},
    }
    out = {"note": "SIMULATED transport (test double); simulator-verified only; no real network or hardware.",
           "scenarios": {}}
    for name, beh in scen.items():
        res, log = run(beh)
        out["scenarios"][name] = {"status": res["status"], "shots_completed": res["shots_completed"],
                                  "virtual_completion_ms": res["virtual_completion_ms"],
                                  "quarantined": res["quarantined_nodes"], "event_kinds": kinds(log),
                                  "aggregate_hash": res["aggregate_hash"][:16]}
    beh_all = {f"n{i}": NodeBehavior(mode="drop_first_n", n=1) for i in range(3)}
    res, log = run(beh_all, max_attempts=3)
    out["scenarios"]["transient_loss_all_links_3_attempts"] = {
        "status": res["status"], "shots_completed": res["shots_completed"], "event_kinds": kinds(log),
        "note": "policy limitation: retries rotate to a new node; all-links-drop-once exhausts 3 attempts"}
    res, log = run(beh_all, max_attempts=4)
    out["scenarios"]["transient_loss_all_links_4_attempts"] = {
        "status": res["status"], "shots_completed": res["shots_completed"], "event_kinds": kinds(log)}
    res, log = run({"slow": NodeBehavior(latency_ms=150.0), "fast": NodeBehavior(latency_ms=10.0)})
    out["scenarios"]["latency_straggler"] = {"status": res["status"], "virtual_completion_ms":
                                             res["virtual_completion_ms"], "event_kinds": kinds(log)}
    res, log = run({"good": NodeBehavior(), "dead": NodeBehavior(mode="down")}, max_attempts=1)
    out["scenarios"]["partial_execution"] = {"status": res["status"], "shots_completed": res["shots_completed"],
                                             "shots_requested": res["shots_requested"],
                                             "uncertainty": res["uncertainty"]}
    return out


if __name__ == "__main__":
    ev = build_evidence()
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qnet_workload_evidence.json")
    json.dump(ev, open(p, "w"), indent=2)
    for k, v in ev["scenarios"].items():
        print(f"{k:28s} {v['status']:9s} shots={v.get('shots_completed')} events={v.get('event_kinds', '')}")
