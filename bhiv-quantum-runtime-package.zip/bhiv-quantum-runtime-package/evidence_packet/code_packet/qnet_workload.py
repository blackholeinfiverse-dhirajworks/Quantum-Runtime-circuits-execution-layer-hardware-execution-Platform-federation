"""
qnet_workload.py -- Phase 4 distributed quantum *application workload* (execution layer).

Workload: a circuit's shots are sharded across N nodes; the coordinator aggregates counts.
It CONSUMES a transport through the `Transport` interface; it does not implement federation
(Kanishk's scope). `SimTransport` is an in-process TEST DOUBLE with a deterministic virtual
clock and scripted faults. Nothing here touches a real network or real hardware; every result
carries certification_state = "SIMULATOR_VERIFIED" and simulated_transport = True.

Guarantees implemented (and tested in test_qnet_workload.py)
  * idempotent invocations   invocation_id = SHA-256(workload, shard, shots, seed, circuit_hash)
  * duplicate suppression    a repeated invocation_id is never double-counted
  * result validation        circuit_hash, shot-sum, and workload-specific support check; a node
                             that fails validation is quarantined and its shard re-run elsewhere
  * bounded retries          timeouts / drops -> NEXT node (rotation); after max_attempts the shard
                             FAILS. Known limitation: the same node is not re-tried until the rotation
                             wraps, so transient loss on every link needs max_attempts > len(nodes)
  * honest partial results   status PARTIAL + shots_completed + widened uncertainty; never
                             presented as COMPLETE
  * append-only hash-chained event log; replay (even from a shuffled log) reconstructs the same
    aggregate
  * advisory only            decision_authority = "NONE" -- no execution/governance authority
No wall-clock time is used: all times are virtual milliseconds.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Protocol

import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector

SCHEMA_VERSION = "qnet-workload-v1"


def sha(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


# ------------------------------------------------------------------ workload registry
def ghz(n: int) -> QuantumCircuit:
    c = QuantumCircuit(n); c.h(0)
    for i in range(n - 1): c.cx(i, i + 1)
    return c


WORKLOADS: Dict[str, dict] = {
    "ghz4": {"circuit": lambda: ghz(4), "allowed": {"0000", "1111"}},
    "bell2": {"circuit": lambda: ghz(2), "allowed": {"00", "11"}},
}


def circuit_hash(name: str) -> str:
    return sha({"workload": name, "ops": [(i.operation.name, [q._index for q in i.qubits])
                                           for i in WORKLOADS[name]["circuit"]().data]})


# ------------------------------------------------------------------ transport interface
@dataclass
class Delivery:
    arrival_ms: float
    response: dict


class Transport(Protocol):
    def send(self, node_id: str, request: dict, now_ms: float) -> List[Delivery]:
        """Return 0 deliveries (message lost / node down), 1, or >1 (duplicates)."""


@dataclass
class NodeBehavior:
    latency_ms: float = 20.0
    mode: str = "ok"            # ok | down | drop_first_n | duplicate | corrupt_support | wrong_circuit
    n: int = 0                  # for drop_first_n


class SimTransport:
    """Deterministic in-process stand-in for a federation transport (TEST DOUBLE)."""

    def __init__(self, behaviors: Dict[str, NodeBehavior]):
        self.behaviors = behaviors
        self.calls: Dict[tuple, int] = {}

    @staticmethod
    def _run(req: dict) -> dict:
        qc = WORKLOADS[req["workload"]]["circuit"]()
        sv = Statevector.from_instruction(qc); sv.seed(req["seed"])
        return {str(k): int(v) for k, v in sv.sample_counts(req["shots"]).items()}

    def send(self, node_id, request, now_ms):
        b = self.behaviors[node_id]
        key = (node_id, request["invocation_id"])
        self.calls[key] = self.calls.get(key, 0) + 1
        if b.mode == "down":
            return []
        if b.mode == "drop_first_n" and self.calls[key] <= b.n:
            return []
        counts = self._run(request)
        chash = request["circuit_hash"]
        if b.mode == "corrupt_support":          # plausible-looking but physically impossible counts
            n = len(next(iter(counts)))
            rng = np.random.default_rng(request["seed"] + 1)
            raw = rng.integers(0, 2 ** n, request["shots"])
            counts = {}
            for v in raw: counts[format(int(v), f"0{n}b")] = counts.get(format(int(v), f"0{n}b"), 0) + 1
        if b.mode == "wrong_circuit":
            chash = "0" * 64
        resp = {"invocation_id": request["invocation_id"], "node_id": node_id,
                "shard": request["shard"], "shots": request["shots"], "counts": counts,
                "circuit_hash": chash}
        d = Delivery(now_ms + b.latency_ms, resp)
        return [d, Delivery(d.arrival_ms + 1.0, dict(resp))] if b.mode == "duplicate" else [d]


# ------------------------------------------------------------------ event log
class EventLog:
    """Append-only, hash-chained. Each event stores seq, prev hash and its own hash."""

    def __init__(self):
        self.events: List[dict] = []

    def append(self, kind: str, **data) -> dict:
        prev = self.events[-1]["hash"] if self.events else "0" * 64
        ev = {"seq": len(self.events), "kind": kind, "data": data, "prev": prev}
        ev["hash"] = sha({k: ev[k] for k in ("seq", "kind", "data", "prev")})
        self.events.append(ev)
        return ev

    @property
    def head(self) -> str:
        return self.events[-1]["hash"] if self.events else "0" * 64


def verify_chain(events: List[dict]) -> bool:
    prev = "0" * 64
    for ev in sorted(events, key=lambda e: e["seq"]):
        if ev["prev"] != prev or ev["hash"] != sha({k: ev[k] for k in ("seq", "kind", "data", "prev")}):
            return False
        prev = ev["hash"]
    return True


# ------------------------------------------------------------------ coordinator
def validate(resp: dict, req: dict) -> Optional[str]:
    if resp.get("invocation_id") != req["invocation_id"]:
        return "invocation_id mismatch"
    if resp.get("circuit_hash") != req["circuit_hash"]:
        return "circuit_hash mismatch"
    counts = resp.get("counts", {})
    if sum(counts.values()) != req["shots"]:
        return "shot total mismatch"
    allowed = WORKLOADS[req["workload"]]["allowed"]
    if not set(counts) <= allowed:
        return f"outcomes outside physical support: {sorted(set(counts) - allowed)[:3]}"
    return None


def run_workload(workload: str, total_shots: int, nodes: List[str], transport: Transport,
                 shards: int = 4, seed: int = 42, timeout_ms: float = 100.0, max_attempts: int = 3):
    if workload not in WORKLOADS:
        raise ValueError(f"unknown workload '{workload}'; known: {sorted(WORKLOADS)}")
    if not isinstance(total_shots, int) or isinstance(total_shots, bool) or total_shots <= 0:
        raise ValueError("total_shots must be a positive integer")
    if not isinstance(shards, int) or shards < 1 or shards > total_shots:
        raise ValueError("shards must be an integer in [1, total_shots]")
    if not nodes or len(set(nodes)) != len(nodes):
        raise ValueError("nodes must be a non-empty list of unique node ids")
    if timeout_ms <= 0 or max_attempts < 1:
        raise ValueError("timeout_ms must be > 0 and max_attempts >= 1")
    log = EventLog()
    chash = circuit_hash(workload)
    per = [total_shots // shards + (1 if i < total_shots % shards else 0) for i in range(shards)]
    trace_id = sha({"workload": workload, "shots": total_shots, "shards": shards, "seed": seed,
                    "schema": SCHEMA_VERSION})[:16]
    log.append("START", workload=workload, total_shots=total_shots, shards=shards, seed=seed,
               nodes=nodes, trace_id=trace_id)
    accepted: Dict[int, dict] = {}
    seen_invocations = set()
    quarantined: set = set()
    shard_done_ms: Dict[int, float] = {}

    for s in range(shards):
        req = {"workload": workload, "shard": s, "shots": per[s], "seed": seed * 1000 + s,
               "circuit_hash": chash}
        req["invocation_id"] = sha({k: req[k] for k in ("workload", "shard", "shots", "seed", "circuit_hash")})
        clock = 0.0
        for attempt in range(max_attempts):
            pool = [n for n in nodes if n not in quarantined]
            if not pool:
                break
            node = pool[(s + attempt) % len(pool)]
            log.append("DISPATCH", shard=s, node=node, attempt=attempt, invocation_id=req["invocation_id"])
            deliveries = sorted(transport.send(node, req, clock), key=lambda d: d.arrival_ms)
            on_time = [d for d in deliveries if d.arrival_ms - clock <= timeout_ms]
            if not on_time:
                log.append("TIMEOUT", shard=s, node=node, attempt=attempt, deliveries=len(deliveries))
                clock += timeout_ms
                continue
            handled_ok = False
            for d in on_time:
                resp = d.response
                if resp["invocation_id"] in seen_invocations:
                    log.append("DUPLICATE_IGNORED", shard=s, node=resp["node_id"],
                               invocation_id=resp["invocation_id"])
                    continue
                err = validate(resp, req)
                if err:
                    log.append("VALIDATION_FAILED", shard=s, node=resp["node_id"], reason=err)
                    quarantined.add(resp["node_id"])
                    clock = d.arrival_ms
                    break
                seen_invocations.add(resp["invocation_id"])
                accepted[s] = resp
                shard_done_ms[s] = d.arrival_ms
                log.append("SHARD_ACCEPTED", shard=s, node=resp["node_id"], shots=resp["shots"],
                           counts=dict(sorted(resp["counts"].items())),
                           invocation_id=resp["invocation_id"], virtual_ms=d.arrival_ms)
                handled_ok = True
            if handled_ok:
                break
        if s not in accepted:
            log.append("SHARD_FAILED", shard=s, attempts=max_attempts)

    return finalize(log, workload, total_shots, shards, trace_id, shard_done_ms, quarantined)


def aggregate(events: List[dict]):
    counts: Dict[str, int] = {}
    done = 0
    for ev in sorted(events, key=lambda e: (e["seq"])):
        if ev["kind"] == "SHARD_ACCEPTED":
            done += ev["data"]["shots"]
            for k, v in ev["data"]["counts"].items():
                counts[k] = counts.get(k, 0) + v
    return dict(sorted(counts.items())), done


def finalize(log, workload, total_shots, shards, trace_id, shard_done_ms, quarantined):
    counts, done = aggregate(log.events)
    complete = done == total_shots
    se = math.sqrt(0.25 / done) if done else None
    log.append("AGGREGATED", shots_completed=done, status="COMPLETE" if complete else "PARTIAL")
    return {
        "schema_version": SCHEMA_VERSION, "workload_id": workload, "trace_id": trace_id,
        "status": "COMPLETE" if complete else "PARTIAL",
        "shots_requested": total_shots, "shots_completed": done, "counts": counts,
        "aggregate_hash": sha(counts), "events_head": log.head,
        "virtual_completion_ms": max(shard_done_ms.values()) if shard_done_ms else None,
        "quarantined_nodes": sorted(quarantined),
        "certification_state": "SIMULATOR_VERIFIED", "simulated_transport": True,
        "decision_authority": "NONE",
        "uncertainty": {"max_outcome_probability_standard_error": se,
                        "note": ("complete" if complete else
                                 "PARTIAL: only the shown shots were executed; do not treat as the full "
                                 "requested sample")},
        "replay_metadata": {"events": len(log.events), "chain_verified": verify_chain(log.events)},
    }, log


def replay(events: List[dict]) -> dict:
    """Reconstruct the aggregate from an event log (any order; sorted by seq; chain verified)."""
    if not verify_chain(events):
        raise ValueError("event log failed hash-chain verification")
    counts, done = aggregate(events)
    return {"counts": counts, "shots_completed": done, "aggregate_hash": sha(counts)}
