"""
hardware_manifest.py -- Phase 5 "Hardware Readiness" (Quantum Runtime / hardware-execution role).

What this produces (HARDWARE_EXECUTION_MANIFEST.json)
  1. A machine-independent manifest per workload with the 16 required fields.
  2. The fields that can only be filled by a real run (provider, backend, topology, calibration,
     transpilation output, job id, measured distribution, noise info, timestamp, provenance) are
     present but set to "NOT_YET_EXECUTED_ON_HARDWARE". Nothing is estimated or invented for them.
  3. Backend adapters with HONEST capability marking: an adapter that lacks its dependency or
     credentials reports unavailable and refuses to execute -- it never mocks success.
  4. A certification gate: simulator output can only ever be SIMULATOR_VERIFIED. HARDWARE_VERIFIED
     requires is_real_hardware=True AND a provider job id; anything else raises.
  5. Real numbers for readiness: transpilation of each workload to GENERIC DEVICE MODELS (line, grid,
     all-to-all; basis rz/sx/x/cz) and noise sensitivity under an ASSUMED noise model. These are
     models, not any real machine.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
from abc import ABC, abstractmethod

import numpy as np
from qiskit import QuantumCircuit, qasm2, transpile
from qiskit.providers.fake_provider import GenericBackendV2
from qiskit.transpiler import CouplingMap
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, ReadoutError, depolarizing_error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "phase3_domains"))
sys.path.insert(0, os.path.join(HERE, "..", "phase4_network"))
import domain_usecases as du                       # noqa: E402
from qnet_workload import ghz                      # noqa: E402

SEED = 42
BASIS = ["rz", "sx", "x", "cz"]
NOISE_ASSUMPTION = {"p_1q_depolarizing": 1e-3, "p_2q_depolarizing": 1e-2, "p_readout_flip": 0.02,
                    "source": "ASSUMED round numbers typical of NISQ superconducting devices; "
                              "not measured from any real device"}
PENDING = "NOT_YET_EXECUTED_ON_HARDWARE"


def sha(o): return hashlib.sha256(json.dumps(o, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


# --------------------------------------------------------------------- adapters
class BackendUnavailable(Exception):
    pass


class BackendAdapter(ABC):
    name = "unnamed"
    provider_type = "SIMULATOR"
    is_real_hardware = False

    @abstractmethod
    def is_available(self) -> dict: ...

    @abstractmethod
    def execute(self, circuit: QuantumCircuit, shots: int, seed: int | None = None) -> dict: ...


class AerAdapter(BackendAdapter):
    name = "aer_simulator"

    def __init__(self, noise_model=None):
        self.noise_model = noise_model

    def is_available(self):
        return {"available": True, "reason": f"qiskit-aer {__import__('qiskit_aer').__version__}"}

    def execute(self, circuit, shots, seed=None):
        if not isinstance(shots, int) or isinstance(shots, bool) or shots <= 0:
            raise ValueError("shots must be a positive integer")
        if not any(i.operation.name == "measure" for i in circuit.data):
            raise ValueError("circuit has no measurements; add measure operations to obtain counts")
        sim = AerSimulator(noise_model=self.noise_model, seed_simulator=seed)
        counts = sim.run(transpile(circuit, sim, seed_transpiler=seed), shots=shots,
                         seed_simulator=seed).result().get_counts()
        return {"counts": counts, "backend": self.name, "provider_type": self.provider_type,
                "is_real_hardware": False, "job_id": None}


class _CloudAdapter(BackendAdapter):
    provider_type = "QPU"
    is_real_hardware = True
    module, env_var = "", ""

    def is_available(self):
        try:
            __import__(self.module)
        except ImportError as e:
            return {"available": False, "reason": f"missing dependency: {e}"}
        if not os.environ.get(self.env_var):
            return {"available": False, "reason": f"credentials not configured ({self.env_var} unset)"}
        return {"available": True, "reason": "dependency and credential env var present (not validated "
                                             "against the provider)"}

    def execute(self, circuit, shots, seed=None):
        st = self.is_available()
        if not st["available"]:
            raise BackendUnavailable(f"{self.name}: {st['reason']}")
        raise NotImplementedError(f"{self.name}: submission is not implemented in this readiness package; "
                                  "implement and run only when hardware access is granted")


class IBMAdapter(_CloudAdapter):
    name, module, env_var = "ibm_quantum", "qiskit_ibm_runtime", "IBM_QUANTUM_TOKEN"


class IonQAdapter(_CloudAdapter):
    name, module, env_var = "ionq", "qiskit_ionq", "IONQ_API_KEY"


REGISTRY = {a.name: a for a in (AerAdapter(), IBMAdapter(), IonQAdapter())}


def adapter_status():
    return {n: a.is_available() for n, a in REGISTRY.items()}


def certify(result: dict) -> str:
    """Certification gate: the two evidence classes can never be conflated."""
    if result.get("is_real_hardware") is True:
        if not result.get("job_id") or not result.get("backend"):
            raise ValueError("hardware certification requires a provider job_id and backend name")
        return "HARDWARE_VERIFIED"
    if result.get("is_real_hardware") is False:
        return "SIMULATOR_VERIFIED"
    raise ValueError("result does not declare is_real_hardware; refusing to certify")


# --------------------------------------------------------------------- fit check
AUTHORITY = {
    "authority_ceiling": "ADVISORY_COMPUTE",
    "negative_authority": [
        "Must not make or execute decisions autonomously (output is advisory input to BHIV governance)",
        "Must not bypass QCG / governance / provenance layers owned by other teams",
        "Must not represent simulator output as hardware evidence",
        "Must not fabricate or estimate hardware-only fields (job id, calibration, device topology)",
        "Must not call real providers without configured credentials and explicit approval",
    ],
}


def check_fit(qubits_required: int, backend_qubits: int, transpiled_depth: int, max_depth: int) -> dict:
    """Pre-flight rejection of workloads that cannot run on a target backend.
    max_depth is a CALLER-SUPPLIED budget (derive it from real calibration data when available);
    this function does not invent device limits."""
    reasons = []
    if qubits_required > backend_qubits:
        reasons.append(f"needs {qubits_required} qubits, backend has {backend_qubits}")
    if transpiled_depth > max_depth:
        reasons.append(f"transpiled depth {transpiled_depth} exceeds budget {max_depth}")
    return {"accepted": not reasons, "reasons": reasons}


# --------------------------------------------------------------------- workloads
def domain_workloads():
    path = os.path.join(HERE, "..", "phase3_domains", "domain_results.json")
    res = json.load(open(path))
    makers = {"VANA": du.vana_fire_risk, "UCICS": du.ucics_housing, "AIAIC": du.aiaic_crops,
              "BHARAT_MALA": du.bharat_mala_hubs, "MARINE": du.marine_vessel_routing}
    out = []
    for key, mk in makers.items():
        p = mk(); E = du.energies(p); scale = math.pi / float(np.ptp(E))
        q = res[key]["qaoa"]
        qc = du.build_circuit(p, scale, q["gammas"], q["betas"], measure=True)
        out.append({"id": f"{key.lower()}_qaoa_p2", "algorithm": "QAOA (p=2)", "domain": p.domain,
                    "circuit": qc, "problem": p, "params": {"gammas": q["gammas"], "betas": q["betas"],
                    "rounding": "5 decimal places as stored in domain_results.json"},
                    "baseline": res[key]["classical_exact"]["method"],
                    "expected": "bitstring distribution concentrated on feasible/low-energy QUBO states; "
                                "decision bits = first n_dec qubits",
                    "input_schema": {"synthetic_instance_seed": 42, "problem": p.description},
                    "ideal_feasible_mass": q["prob_mass_on_feasible"]})
    for name, n in (("ghz4_distributed_shots", 4), ("bell2_link_check", 2)):
        qc = ghz(n); qc.measure_all()
        out.append({"id": name, "algorithm": "GHZ/Bell state preparation", "domain": "network workload",
                    "circuit": qc, "problem": None, "params": {},
                    "baseline": "exact statevector: P(0..0)=P(1..1)=0.5",
                    "expected": f"only outcomes {'0'*n} and {'1'*n}, each ~0.5",
                    "input_schema": {"n_qubits": n}, "ideal_feasible_mass": 1.0})
    return out


def interaction_stats(qc: QuantumCircuit):
    pairs = set()
    for ins in qc.data:
        if ins.operation.num_qubits == 2:
            a, b = (qc.find_bit(q).index for q in ins.qubits); pairs.add((min(a, b), max(a, b)))
    deg = {}
    for a, b in pairs: deg[a] = deg.get(a, 0) + 1; deg[b] = deg.get(b, 0) + 1
    return {"distinct_two_qubit_pairs": len(pairs), "max_interaction_degree": max(deg.values(), default=0)}


def device_models(n):
    side = math.ceil(math.sqrt(n)); rows = side; cols = math.ceil(n / side)
    grid = [[r * cols + c, r * cols + c + 1] for r in range(rows) for c in range(cols - 1)
            if r * cols + c + 1 < n] + \
           [[r * cols + c, (r + 1) * cols + c] for r in range(rows - 1) for c in range(cols)
            if (r + 1) * cols + c < n]
    line = [[i, i + 1] for i in range(n - 1)]
    return {"all_to_all": None, "line": line, "grid": grid}


def transpile_table(qc):
    n = qc.num_qubits; rows = {}
    for name, edges in device_models(n).items():
        cm = None if edges is None else CouplingMap(edges + [[b, a] for a, b in edges])
        t = transpile(qc, basis_gates=BASIS, coupling_map=cm, optimization_level=1, seed_transpiler=SEED)
        ops = dict(t.count_ops())
        rows[name] = {"depth": t.depth(), "two_qubit_gates": int(ops.get("cz", 0)),
                      "gate_counts": {k: int(v) for k, v in ops.items() if k not in ("measure", "barrier")}}
    return rows


def noise_sensitivity(w, shots=512):
    """Task-level degradation under the ASSUMED noise model (feasible-shot fraction)."""
    nm = NoiseModel()
    nm.add_all_qubit_quantum_error(depolarizing_error(NOISE_ASSUMPTION["p_1q_depolarizing"], 1),
                                   ["rz", "sx", "x", "h", "rx", "ry"])
    nm.add_all_qubit_quantum_error(depolarizing_error(NOISE_ASSUMPTION["p_2q_depolarizing"], 2),
                                   ["cx", "cz", "rzz"])
    f = NOISE_ASSUMPTION["p_readout_flip"]
    nm.add_all_qubit_readout_error(ReadoutError([[1 - f, f], [f, 1 - f]]))
    qc = w["circuit"]
    pre = transpile(qc, basis_gates=["rz", "sx", "x", "cx"], optimization_level=1, seed_transpiler=SEED)
    ideal = AerAdapter().execute(pre, shots, SEED)
    noisy = AerAdapter(nm).execute(pre, shots, SEED)

    def metric(counts):
        tot = sum(counts.values()); p = w["problem"]
        if p is None:
            allowed = {"0" * qc.num_qubits, "1" * qc.num_qubits} if False else None
            ok = sum(v for k, v in counts.items() if len(set(k.replace(" ", ""))) == 1)
            return ok / tot
        ok = 0
        for k, v in counts.items():
            bits = tuple(int(c) for c in reversed(k.replace(" ", "")))
            if p.feasible(bits[:p.n_dec]): ok += v
        return ok / tot
    mi, mn = metric(ideal["counts"]), metric(noisy["counts"])
    return {"shots": shots, "metric": "fraction of shots that are valid (feasible / GHZ-supported)",
            "ideal": round(mi, 4), "noisy_assumed_model": round(mn, 4),
            "absolute_drop": round(mi - mn, 4),
            "standard_error_each": round(math.sqrt(0.25 / shots), 4)}


def build_manifest():
    ws = domain_workloads()
    manifest_workloads = []
    for w in ws:
        qc = w["circuit"]
        tt = transpile_table(qc)
        qasm = qasm2.dumps(qc.remove_final_measurements(inplace=False)) if False else None
        spec = {"id": w["id"], "qasm_hash_basis": sha([(i.operation.name, [qc.find_bit(q).index for q in i.qubits],
                [round(float(p), 9) for p in i.operation.params]) for i in qc.data])}
        manifest_workloads.append({
            "WORKLOAD_ID": sha(spec)[:16], "workload_name": w["id"], "ALGORITHM": w["algorithm"],
            "domain": w["domain"], "INPUT_SCHEMA": w["input_schema"],
            "CIRCUIT": {"logical_depth": qc.depth(), "logical_gate_counts":
                        {k: int(v) for k, v in qc.count_ops().items()},
                        "circuit_sha256_of_ops": spec["qasm_hash_basis"],
                        "note": "full circuit reproducible from domain_usecases.build_circuit / ghz()"},
            "QUBITS_REQUIRED": qc.num_qubits,
            "DEPTH": {"logical": qc.depth(), "transpiled_to_generic_device_models": tt},
            "GATE_SET": {"logical": sorted(k for k in qc.count_ops() if k not in ("measure", "barrier")),
                         "target_basis_assumed": BASIS},
            "SHOTS": {"recommended_minimum": 1024, "note": "single-run shot count to be set per hardware "
                      "queue/cost; simulator runs used 4096 (domain) / 512 (noise study)"},
            "PARAMETERS": w["params"],
            "EXPECTED_OUTPUT": w["expected"],
            "CLASSICAL_BASELINE": w["baseline"],
            "NOISE_ASSUMPTIONS": NOISE_ASSUMPTION,
            "NOISE_SENSITIVITY_SIMULATED": noise_sensitivity(w),
            "ERROR_HANDLING": {"unavailable_backend": "adapter reports unavailable; BackendUnavailable raised",
                               "excess_qubits": "reject if QUBITS_REQUIRED > backend qubits",
                               "excess_depth": "reject/flag if transpiled depth exceeds the backend's "
                                               "coherence-limited budget (use the depth table as the input)",
                               "timeout_or_partial": "report PARTIAL with shots_completed; never COMPLETE"},
            "AUTHORITY": AUTHORITY,
            "PROVENANCE": {"generator": "hardware_manifest.py", "seed": SEED,
                           "synthetic_data": w["problem"] is not None,
                           "certification_state": "SIMULATOR_VERIFIED",
                           "decision_authority": "NONE (advisory)"},
            "REPLAY_METADATA": {"seed_simulator": SEED, "seed_transpiler": SEED,
                                "same_params_same_seed_reproduces_counts": True},
            "HARDWARE_REQUIREMENTS": {"min_qubits": qc.num_qubits,
                                      **interaction_stats(qc),
                                      "connectivity_note": "dense interaction graphs need SWAP routing on "
                                      "sparse devices; compare 'all_to_all' vs 'line'/'grid' two_qubit_gates",
                                      "mid_circuit_measurement": False},
            "HARDWARE_FIELDS_TO_FILL_ON_ARRIVAL": {k: PENDING for k in (
                "provider", "backend_device", "device_topology", "qubit_count", "connectivity", "gate_set",
                "calibration_information", "transpilation_output", "job_id", "shots", "measured_distribution",
                "error_noise_information", "execution_timestamp", "provenance")},
        })
    return {
        "manifest_version": "bhq-hw-manifest-v1",
        "certification_policy": "Simulator evidence is SIMULATOR_VERIFIED only. HARDWARE_VERIFIED requires "
                                "is_real_hardware=True and a provider job_id (enforced by certify()).",
        "environment": {"qiskit": __import__("qiskit").__version__,
                        "qiskit_aer": __import__("qiskit_aer").__version__, "python": sys.version.split()[0]},
        "backend_adapters": adapter_status(),
        "workloads": manifest_workloads,
        "hardware_execution_status": "NOT EXECUTED — no hardware access; no hardware results exist or are claimed",
        "device_models_note": "line / grid / all-to-all coupling maps are generic models, not any real device.",
    }


if __name__ == "__main__":
    m = build_manifest()
    path = os.path.join(HERE, "HARDWARE_EXECUTION_MANIFEST.json")
    json.dump(m, open(path, "w"), indent=2, default=str)
    print("adapters:", {k: v["available"] for k, v in m["backend_adapters"].items()})
    for w in m["workloads"]:
        d = w["DEPTH"]["transpiled_to_generic_device_models"]
        ns = w["NOISE_SENSITIVITY_SIMULATED"]
        print(f"{w['workload_name']:24s} q={w['QUBITS_REQUIRED']:2d} cz(all/line/grid)="
              f"{d['all_to_all']['two_qubit_gates']}/{d['line']['two_qubit_gates']}/{d['grid']['two_qubit_gates']} "
              f"depth(all/line/grid)={d['all_to_all']['depth']}/{d['line']['depth']}/{d['grid']['depth']} "
              f"valid-shots ideal={ns['ideal']} noisy={ns['noisy_assumed_model']}")
