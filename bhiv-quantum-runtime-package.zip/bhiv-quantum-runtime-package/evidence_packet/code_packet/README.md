# Code packet (5 files)

Entry point → core algorithm → execution/adapter → domain integration → evidence:

| Role | File (copy of the repo file) |
|---|---|
| Entry point / adapter / manifest | `hardware_manifest.py` (from `phase5_hardware/`) |
| Core algorithm + domain integration | `domain_usecases.py` (from `phase3_domains/`) |
| Execution / network | `qnet_workload.py` (from `phase4_network/`) |
| Evidence — governance & execution tests | `test_governance_execution.py` (from `phase6_testing/`) |
| Evidence — network failure scenarios | `test_qnet_workload.py` (from `phase6_testing/`) |

These are copies for review convenience; the repo files are authoritative. They import sibling folders,
so run tests from the repo root, not from this folder.
