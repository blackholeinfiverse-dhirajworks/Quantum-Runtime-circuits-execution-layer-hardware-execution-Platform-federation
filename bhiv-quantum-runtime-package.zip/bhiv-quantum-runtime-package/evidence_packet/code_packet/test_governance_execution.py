"""
test_governance_execution.py -- Phase 6: governance + quantum-execution tests.

Governance : authority ceiling, negative authority, provenance, trace continuity, schema version,
             replayability, uncertainty disclosure.
Execution  : invalid inputs, excessive qubits / depth, noise, measurement (readout) errors,
             timeout / failure (see test_qnet_workload.py for the networking cases),
             unavailable backend, certification gate (simulator never == hardware).

    pytest test_governance_execution.py -v
Requires HARDWARE_EXECUTION_MANIFEST.json (run phase5_hardware/hardware_manifest.py first).
"""
import json
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
for sub in ("phase4_network", "phase5_hardware", "phase3_domains"):
    sys.path.insert(0, os.path.join(HERE, "..", sub))

from qnet_workload import (NodeBehavior, SimTransport, run_workload, replay, verify_chain,
                           SCHEMA_VERSION)
import hardware_manifest as hm
from qiskit import QuantumCircuit

MANIFEST = json.load(open(os.path.join(HERE, "..", "phase5_hardware", "HARDWARE_EXECUTION_MANIFEST.json")))
DOMAIN = json.load(open(os.path.join(HERE, "..", "phase3_domains", "domain_results.json")))
REQUIRED = ["WORKLOAD_ID", "ALGORITHM", "INPUT_SCHEMA", "CIRCUIT", "QUBITS_REQUIRED", "DEPTH", "GATE_SET",
            "SHOTS", "PARAMETERS", "EXPECTED_OUTPUT", "CLASSICAL_BASELINE", "NOISE_ASSUMPTIONS",
            "ERROR_HANDLING", "PROVENANCE", "REPLAY_METADATA", "HARDWARE_REQUIREMENTS"]


def tiny_measured():
    c = QuantumCircuit(1, 1); c.h(0); c.measure(0, 0)
    return c


def net_run(behaviors=None, **kw):
    beh = behaviors or {f"n{i}": NodeBehavior() for i in range(3)}
    return run_workload("ghz4", 2048, list(beh), SimTransport(beh), **kw)


# ------------------------------------------------------------------ governance
@pytest.mark.parametrize("w", MANIFEST["workloads"], ids=lambda w: w["workload_name"])
def test_every_workload_has_all_16_required_fields(w):
    assert all(k in w for k in REQUIRED), [k for k in REQUIRED if k not in w]


@pytest.mark.parametrize("w", MANIFEST["workloads"], ids=lambda w: w["workload_name"])
def test_authority_ceiling_and_negative_authority_declared(w):
    a = w["AUTHORITY"]
    assert a["authority_ceiling"] == "ADVISORY_COMPUTE"
    assert len(a["negative_authority"]) >= 3
    assert any("bypass" in n.lower() and "governance" in n.lower() for n in a["negative_authority"])
    assert any("simulator" in n.lower() and "hardware" in n.lower() for n in a["negative_authority"])


@pytest.mark.parametrize("w", MANIFEST["workloads"], ids=lambda w: w["workload_name"])
def test_no_decision_authority_and_never_hardware_certified(w):
    assert w["PROVENANCE"]["decision_authority"].startswith("NONE")
    assert w["PROVENANCE"]["certification_state"] == "SIMULATOR_VERIFIED"


@pytest.mark.parametrize("w", MANIFEST["workloads"], ids=lambda w: w["workload_name"])
def test_hardware_only_fields_are_pending_not_invented(w):
    vals = set(w["HARDWARE_FIELDS_TO_FILL_ON_ARRIVAL"].values())
    assert vals == {"NOT_YET_EXECUTED_ON_HARDWARE"}


def test_manifest_declares_no_hardware_execution_and_has_schema_version():
    assert MANIFEST["manifest_version"].startswith("bhq-hw-manifest-")
    assert "NOT EXECUTED" in MANIFEST["hardware_execution_status"]


def test_workload_ids_unique_and_deterministic():
    ids = [w["WORKLOAD_ID"] for w in MANIFEST["workloads"]]
    assert len(set(ids)) == len(ids)
    assert [w["WORKLOAD_ID"] for w in hm.build_manifest()["workloads"]] == ids   # rebuilt == stored


def test_trace_continuity_every_event_belongs_to_one_trace_and_ids_match():
    res, log = net_run({"n0": NodeBehavior(), "n1": NodeBehavior(mode="duplicate"),
                        "n2": NodeBehavior(mode="down")})
    start = log.events[0]
    assert start["kind"] == "START" and start["data"]["trace_id"] == res["trace_id"]
    assert verify_chain(log.events)
    assert res["events_head"] == log.head != "0" * 64          # result is bound to the verified chain head
    dispatched = {e["data"]["invocation_id"] for e in log.events if e["kind"] == "DISPATCH"}
    accepted = {e["data"]["invocation_id"] for e in log.events if e["kind"] == "SHARD_ACCEPTED"}
    assert accepted <= dispatched                         # nothing accepted that was never dispatched


def test_schema_version_present_and_checked():
    res, _ = net_run()
    assert res["schema_version"] == SCHEMA_VERSION


def test_replayability_same_seed_same_counts_through_backend_adapter():
    w = next(x for x in hm.domain_workloads() if x["id"] == "ucics_qaoa_p2")
    a = hm.AerAdapter().execute(w["circuit"], 1024, seed=11)["counts"]
    b = hm.AerAdapter().execute(w["circuit"], 1024, seed=11)["counts"]
    assert a == b


def test_replayability_event_log_reconstructs_aggregate():
    res, log = net_run()
    assert replay(log.events)["aggregate_hash"] == res["aggregate_hash"]


def test_uncertainty_disclosed_everywhere():
    res, _ = net_run()
    assert res["uncertainty"]["max_outcome_probability_standard_error"] > 0
    for k, v in DOMAIN.items():
        assert "uncertainty" in v and "heuristic" in v["uncertainty"]["note"], k
    for w in MANIFEST["workloads"]:
        assert w["NOISE_SENSITIVITY_SIMULATED"]["standard_error_each"] > 0
        assert "assumed" in json.dumps(w["NOISE_ASSUMPTIONS"]).lower()


def test_domain_results_flag_synthetic_data_and_no_advantage_claim():
    for k, v in DOMAIN.items():
        assert v["synthetic_data"] is True, k


# ------------------------------------------------------------------ certification gate
def test_certify_simulator_result_is_simulator_verified():
    r = hm.AerAdapter().execute(tiny_measured(), 8, seed=1)
    assert hm.certify(r) == "SIMULATOR_VERIFIED"


def test_certify_refuses_hardware_claim_without_job_id():
    with pytest.raises(ValueError):
        hm.certify({"is_real_hardware": True, "backend": "some_qpu", "job_id": None})
    with pytest.raises(ValueError):
        hm.certify({"is_real_hardware": True, "backend": None, "job_id": "abc"})


def test_certify_refuses_undeclared_provenance():
    with pytest.raises(ValueError):
        hm.certify({"counts": {"0": 1}})


def test_certify_hardware_requires_both_flag_and_job_id():
    # pure gate logic with a synthetic dict; this is NOT hardware evidence
    assert hm.certify({"is_real_hardware": True, "backend": "x", "job_id": "j1"}) == "HARDWARE_VERIFIED"


def test_simulator_adapter_can_never_emit_hardware_flag():
    r = hm.AerAdapter().execute(tiny_measured(), 8, seed=1)
    assert r["is_real_hardware"] is False and r["provider_type"] == "SIMULATOR"


def test_adapter_rejects_unmeasured_circuit_and_bad_shots_with_clear_errors():
    with pytest.raises(ValueError, match="no measurements"):
        hm.AerAdapter().execute(QuantumCircuit(1, 1), 8, seed=1)
    for bad in (0, -1, True, 1.5):
        with pytest.raises(ValueError, match="shots"):
            hm.AerAdapter().execute(tiny_measured(), bad, seed=1)


# ------------------------------------------------------------------ unavailable backend / failure
@pytest.mark.parametrize("name", ["ibm_quantum", "ionq"])
def test_cloud_adapters_marked_unavailable_and_refuse_to_execute(name, monkeypatch):
    for v in ("IBM_QUANTUM_TOKEN", "IONQ_API_KEY"):
        monkeypatch.delenv(v, raising=False)
    ad = hm.REGISTRY[name]
    st = ad.is_available()
    assert st["available"] is False and st["reason"]
    with pytest.raises(hm.BackendUnavailable):
        ad.execute(QuantumCircuit(1, 1), 8)


def test_credential_alone_does_not_make_a_missing_dependency_available(monkeypatch):
    monkeypatch.setenv("IONQ_API_KEY", "dummy")
    st = hm.REGISTRY["ionq"].is_available()
    if st["available"] is False:
        assert "dependency" in st["reason"] or "credentials" in st["reason"]


def test_adapter_status_is_honest_aer_only_here():
    st = hm.adapter_status()
    assert st["aer_simulator"]["available"] is True


# ------------------------------------------------------------------ invalid inputs / limits
@pytest.mark.parametrize("kw", [dict(total_shots=0), dict(total_shots=-5), dict(total_shots=True),
                                dict(total_shots=3, shards=5), dict(shards=0)])
def test_invalid_shot_and_shard_inputs_rejected(kw):
    args = dict(workload="ghz4", total_shots=64, nodes=["a"], transport=SimTransport({"a": NodeBehavior()}))
    args.update(kw)
    with pytest.raises(ValueError):
        run_workload(**args)


def test_unknown_workload_and_bad_node_lists_rejected():
    t = SimTransport({"a": NodeBehavior()})
    with pytest.raises(ValueError):
        run_workload("nope", 64, ["a"], t)
    with pytest.raises(ValueError):
        run_workload("ghz4", 64, [], t)
    with pytest.raises(ValueError):
        run_workload("ghz4", 64, ["a", "a"], t)
    with pytest.raises(ValueError):
        run_workload("ghz4", 64, ["a"], t, timeout_ms=0)


def test_excessive_qubits_and_depth_rejected_by_fit_check():
    big = next(w for w in MANIFEST["workloads"] if w["workload_name"] == "vana_qaoa_p2")
    depth = big["DEPTH"]["transpiled_to_generic_device_models"]["line"]["depth"]
    r = hm.check_fit(big["QUBITS_REQUIRED"], backend_qubits=5, transpiled_depth=depth, max_depth=100)
    assert r["accepted"] is False and len(r["reasons"]) == 2
    ok = hm.check_fit(2, backend_qubits=5, transpiled_depth=8, max_depth=100)
    assert ok["accepted"] is True and ok["reasons"] == []


def test_fit_check_flags_depth_only_failure():
    r = hm.check_fit(4, backend_qubits=27, transpiled_depth=500, max_depth=100)
    assert r["accepted"] is False and "depth" in r["reasons"][0]


# ------------------------------------------------------------------ noise & measurement errors
def test_assumed_noise_degrades_every_workload_and_mean_drop_is_material():
    drops = []
    for w in MANIFEST["workloads"]:
        n = w["NOISE_SENSITIVITY_SIMULATED"]
        assert n["noisy_assumed_model"] <= n["ideal"] + 1e-9, w["workload_name"]
        drops.append(n["absolute_drop"])
    assert sum(drops) / len(drops) > 0.05


def test_readout_error_mitigation_experiment_recorded_and_passed():
    p = os.path.join(HERE, "..", "phase1_learning", "learning_results.json")
    r = json.load(open(p))["experiments"]["E10"]
    assert r["passed"] and abs(r["mitigated_ZZ"] - 1) < abs(r["raw_ZZ"] - 1)
