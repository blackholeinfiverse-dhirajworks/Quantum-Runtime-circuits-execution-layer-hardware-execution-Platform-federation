# API samples — none in this package

This package contains no HTTP API. Runtime/API samples belong to the Marine Quantum Runtime service
(separate repository). When captured from the real deployment, place sanitised request/response pairs
here (remove tokens/keys). Document any 401 or unavailable-endpoint responses **as blockers**; do not
bypass authentication or simulate a successful live call.
