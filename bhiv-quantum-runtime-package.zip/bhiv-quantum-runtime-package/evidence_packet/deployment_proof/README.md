# Deployment proof — PENDING

Not produced by this package. Add evidence for the deployed Marine runtime (e.g. dashboard deploy
record with commit hash and timestamp, service URL, a health/backend endpoint response).
Confirm which service URL is canonical before citing it, and label the backend classification
exactly as verified (e.g. simulated/AerSimulator) — never as physical hardware.
