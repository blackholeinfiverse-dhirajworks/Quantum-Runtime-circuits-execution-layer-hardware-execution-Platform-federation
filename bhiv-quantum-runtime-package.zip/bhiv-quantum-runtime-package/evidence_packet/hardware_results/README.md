# Hardware results — EMPTY BY DESIGN

No quantum hardware was accessed; no hardware result exists or is claimed.
When access arrives: run a workload through a real provider adapter, record provider, backend,
topology, calibration, transpilation output, job id, shots, measured distribution, noise info,
timestamp and provenance (the fields listed as NOT_YET_EXECUTED_ON_HARDWARE in
`phase5_hardware/HARDWARE_EXECUTION_MANIFEST.json`), and pass the result through
`hardware_manifest.certify()` — it returns HARDWARE_VERIFIED only with `is_real_hardware=True`
AND a provider job id. Simulator output must never be stored here.
