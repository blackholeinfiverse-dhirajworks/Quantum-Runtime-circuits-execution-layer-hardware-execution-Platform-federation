"""
qnet_physics.py -- Phase 4 quantum-network *application-layer* physics (exact density-matrix
simulation; no hardware, no real network).

1. Entanglement distribution over a noisy link
     Bell pair, one half sent through a depolarising link with parameter lam:
         rho = (1-lam)|Phi+><Phi+| + lam I/4         (Werner state, visibility v = 1-lam)
     Fidelity F = (1+3v)/4 ;  CHSH S = 2*sqrt(2)*v ;  S > 2  <=>  v > 1/sqrt(2)  (lam < 0.2929)

2. Entanglement swapping over a chain of m identical links (repeater-style)
     Werner visibilities multiply: v_chain = v^m. Max hops with S > 2 follows.

3. Non-local (distributed) CNOT between two nodes using one shared Bell pair, with only
     local gates + classical communication (deferred-measurement form). With a noisy pair the
     gate degrades; average gate fidelity is reported.

Everything is checked against closed-form expectations.
"""
from __future__ import annotations

import json
import math
import os

import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import (DensityMatrix, Kraus, Operator, Pauli, SparsePauliOp,
                                 Statevector, average_gate_fidelity, partial_trace,
                                 state_fidelity)
from qiskit_aer.noise import depolarizing_error

_bell = QuantumCircuit(2); _bell.h(0); _bell.cx(0, 1)
PHI = Statevector.from_instruction(_bell)


def werner_link(lam: float) -> DensityMatrix:
    rho = DensityMatrix(PHI)
    return rho.evolve(Kraus(depolarizing_error(lam, 1)), qargs=[1]) if lam > 0 else rho


def chsh(rho: DensityMatrix) -> float:
    def corr(ta, tb):
        A = SparsePauliOp(["Z", "X"], [math.cos(ta), math.sin(ta)])
        B = SparsePauliOp(["Z", "X"], [math.cos(tb), math.sin(tb)])
        return float(np.real(rho.expectation_value(B.tensor(A))))
    a0, a1, b0, b1 = 0, math.pi / 2, math.pi / 4, -math.pi / 4
    return corr(a0, b0) + corr(a0, b1) + corr(a1, b0) - corr(a1, b1)


def link_table():
    rows = []
    for lam in (0.0, 0.05, 0.10, 0.20, 0.25, 0.29, 0.30, 0.40):
        rho = werner_link(lam); v = 1 - lam
        F = float(state_fidelity(rho, PHI)); S = chsh(rho)
        rows.append({"lam": lam, "visibility": v, "fidelity": F, "fidelity_analytic": (1 + 3 * v) / 4,
                     "S_chsh": S, "S_analytic": 2 * math.sqrt(2) * v, "violates_bell": S > 2})
    return rows


def swap(rho12: DensityMatrix, rho34: DensityMatrix):
    """Entanglement swapping: Bell-project the middle qubits (1,2) onto |Phi+> and return the
    normalised state of the outer qubits (0,3) and the outcome probability. The |Phi+> outcome needs
    no Pauli correction; the other three outcomes are Pauli-equivalent."""
    joint = rho34.tensor(rho12)                       # rho12 -> qubits 0,1 ; rho34 -> qubits 2,3
    P = np.zeros((16, 16), dtype=complex)             # index = q3 q2 q1 q0 (q0 least significant)
    for q3 in range(2):
        for q0 in range(2):
            for a in range(2):                        # a = q2, b = q1 in the ket
                for b in range(2):
                    for c in range(2):                # c = q2, d = q1 in the bra
                        for d in range(2):
                            amp = (0.5 if (a == b and c == d) else 0.0)   # |Phi+><Phi+| = 1/2 sum
                            P[q3 * 8 + a * 4 + b * 2 + q0, q3 * 8 + c * 4 + d * 2 + q0] += amp
    out = P @ joint.data @ P.conj().T
    prob = float(np.real(np.trace(out)))
    return partial_trace(DensityMatrix(out / prob), [1, 2]), prob


def chain_table(lam=0.05, max_links=8):
    rows = []
    v = 1 - lam
    rho = werner_link(lam)
    for m in range(1, max_links + 1):
        if m > 1:
            rho, _ = swap(rho, werner_link(lam))
        S = chsh(rho); F = float(state_fidelity(rho, PHI))
        rows.append({"links": m, "S_chsh": S, "S_analytic": 2 * math.sqrt(2) * v ** m,
                     "fidelity": F, "fidelity_analytic": (1 + 3 * v ** m) / 4, "violates_bell": S > 2})
    max_hops_analytic = math.floor(math.log(1 / math.sqrt(2)) / math.log(v))
    # largest m with v^m > 1/sqrt2
    m_max = max(r["links"] for r in rows if r["S_analytic"] > 2) if any(r["S_analytic"] > 2 for r in rows) else 0
    return rows, m_max


def nonlocal_cnot_check(lam_values=(0.0, 0.05, 0.1, 0.2)):
    """Compare against an ideal local CNOT(control=q0,target=q3) on the data qubits. Because the two
    comm qubits (1,2) end in a known state only for the ideal Bell pair, fidelity is computed on the
    reduced data-qubit channel via process (Choi-like) averaging over input product states."""
    rng = np.random.default_rng(7)
    inputs = []
    for _ in range(24):
        a = rng.normal(size=2) + 1j * rng.normal(size=2); a /= np.linalg.norm(a)
        b = rng.normal(size=2) + 1j * rng.normal(size=2); b /= np.linalg.norm(b)
        inputs.append((a, b))
    ideal = QuantumCircuit(2); ideal.cx(0, 1)
    rows = []
    for lam in lam_values:
        fids = []
        for a, b in inputs:
            # register: q0=control, q1,q2 comm (|00>), q3 target. Build state = |ctrl> (x) |00> (x) |tgt>
            psi = np.kron(np.kron(b, np.array([1, 0, 0, 0], dtype=complex)), a)  # q3 (x) q2q1 (x) q0
            rho = DensityMatrix(psi)
            # prepare the Bell pair on (1,2) with link noise on B's half
            prep = QuantumCircuit(4); prep.h(1); prep.cx(1, 2)
            rho = rho.evolve(prep)
            if lam > 0:
                rho = rho.evolve(Kraus(depolarizing_error(lam, 1)), qargs=[2])
            body = QuantumCircuit(4)
            # q0 = control (node A), q1/q2 = shared pair halves (A/B), q3 = target (node B).
            # A: CX(control->q1) then 'measure q1' (X-correction on q2, deferred as CX(1,2));
            # B: CX(q2->target), 'measure q2 in X basis' (Z-correction on control, deferred as CZ).
            body.cx(0, 1); body.cx(1, 2); body.cx(2, 3); body.h(2); body.cz(2, 0)
            rho = rho.evolve(body)
            data = partial_trace(rho, [1, 2])                         # qubits (q0, q3) -> (0,1)
            tgt = Statevector(np.kron(b, a)).evolve(ideal)            # ideal output of local CNOT
            fids.append(float(state_fidelity(data, tgt)))
        rows.append({"lam_on_shared_pair": lam, "mean_state_fidelity_vs_local_CNOT": float(np.mean(fids)),
                     "min_state_fidelity": float(np.min(fids))})
    return rows


def main():
    out = {"link": link_table()}
    chain_rows, m_max = chain_table(0.05)
    out["chain_lam_0.05"] = {"rows": chain_rows, "max_links_with_S_gt_2": m_max}
    out["nonlocal_cnot"] = nonlocal_cnot_check()
    for r in out["link"]:
        assert abs(r["fidelity"] - r["fidelity_analytic"]) < 1e-9 and abs(r["S_chsh"] - r["S_analytic"]) < 1e-9
        assert r["violates_bell"] == (r["lam"] < 1 - 1 / math.sqrt(2) - 1e-12 or
                                      (r["S_analytic"] > 2))
    for r in chain_rows:
        assert abs(r["S_chsh"] - r["S_analytic"]) < 1e-9, r
    assert out["nonlocal_cnot"][0]["min_state_fidelity"] > 1 - 1e-9, out["nonlocal_cnot"][0]
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "qnet_physics_results.json")
    json.dump(out, open(path, "w"), indent=2, default=float)
    print("link: lam -> (F, S, violates)")
    for r in out["link"]:
        print(f"  {r['lam']:.2f}  F={r['fidelity']:.4f}  S={r['S_chsh']:.4f}  Bell-violating={r['violates_bell']}")
    print(f"chain (lam=0.05 per link): max links with S>2 = {m_max}")
    for r in chain_rows: print(f"  m={r['links']}  S={r['S_chsh']:.4f}  F={r['fidelity']:.4f}")
    print("non-local CNOT:")
    for r in out["nonlocal_cnot"]:
        print(f"  lam={r['lam_on_shared_pair']:.2f}  mean F={r['mean_state_fidelity_vs_local_CNOT']:.4f}  "
              f"min F={r['min_state_fidelity']:.4f}")


if __name__ == "__main__":
    main()
