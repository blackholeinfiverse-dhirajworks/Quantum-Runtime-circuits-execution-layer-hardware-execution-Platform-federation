"""
learning_experiments.py -- Phase 1 "Quantum Foundations": concept -> executable experiment.

Each experiment prints its result, asserts it against an ANALYTIC expectation (so a wrong
implementation fails loudly), and is recorded in learning_results.json. Seeded; deterministic.
Note: this is executable evidence of the concepts, not a substitute for studying them --
modify the parameters, predict the outcome first, then run.
"""
from __future__ import annotations

import json
import math
import os

import numpy as np
from scipy.optimize import minimize
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import (DensityMatrix, Kraus, Operator, Pauli, SparsePauliOp,
                                 Statevector, entropy, partial_trace, state_fidelity)
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, ReadoutError, depolarizing_error

RESULTS: dict = {}


def record(exp_id, concept, ok, **detail):
    RESULTS[exp_id] = {"concept": concept, "passed": bool(ok), **detail}
    print(f"[{'PASS' if ok else 'FAIL'}] {exp_id:4s} {concept}")
    assert ok, f"{exp_id} failed: {detail}"


def e01():  # qubit state, superposition, probability amplitudes
    c = QuantumCircuit(1); c.h(0)
    sv = Statevector.from_instruction(c)
    ok = np.allclose(sv.data, [1 / math.sqrt(2)] * 2) and np.allclose(sv.probabilities(), [0.5, 0.5])
    record("E01", "qubit / superposition / amplitudes (H|0> = (|0>+|1>)/sqrt2)", ok,
           amplitudes=[float(a.real) for a in sv.data], probabilities=sv.probabilities().tolist())


def e02():  # Bloch sphere
    theta, phi = 1.1, 0.7
    c = QuantumCircuit(1); c.ry(theta, 0); c.rz(phi, 0)
    sv = Statevector.from_instruction(c)
    bloch = [float(np.real(sv.expectation_value(Pauli(p)))) for p in "XYZ"]
    expect = [math.sin(theta) * math.cos(phi), math.sin(theta) * math.sin(phi), math.cos(theta)]
    ok = np.allclose(bloch, expect, atol=1e-12) and abs(np.linalg.norm(bloch) - 1) < 1e-12
    record("E02", "Bloch sphere: <X>,<Y>,<Z> of Ry(t)Rz(p)|0> = (sin t cos p, sin t sin p, cos t)",
           ok, bloch_vector=bloch, analytic=expect)


def e03():  # measurement + shots: error ~ N^-1/2
    rng = np.random.default_rng(42)
    Ns = [100, 400, 1600, 6400, 25600]
    mean_err = [float(np.mean([abs(rng.binomial(N, 0.5) / N - 0.5) for _ in range(400)])) for N in Ns]
    slope = float(np.polyfit(np.log(Ns), np.log(mean_err), 1)[0])
    record("E03", "measurement & shots: |p_hat - p| scales as N^-1/2", abs(slope + 0.5) < 0.08,
           shots=Ns, mean_abs_error=mean_err, loglog_slope=slope, expected_slope=-0.5)


def e04():  # interference vs measurement
    hh = QuantumCircuit(1); hh.h(0); hh.h(0)
    p_interf = Statevector.from_instruction(hh).probabilities()[0]
    hzh = QuantumCircuit(1); hzh.h(0); hzh.z(0); hzh.h(0)
    p_phase = Statevector.from_instruction(hzh).probabilities()[1]
    c1 = QuantumCircuit(1); c1.h(0)
    rho = DensityMatrix.from_instruction(c1)
    dephased = DensityMatrix(np.diag(np.diag(rho.data)))      # measurement without recording
    c2 = QuantumCircuit(1); c2.h(0)
    p_meas = float(dephased.evolve(c2).probabilities()[0])
    ok = abs(p_interf - 1) < 1e-12 and abs(p_phase - 1) < 1e-12 and abs(p_meas - 0.5) < 1e-12
    record("E04", "interference: H.H=I and H.Z.H=X; a measurement between the H's destroys it",
           ok, p0_HH=float(p_interf), p1_HZH=float(p_phase), p0_with_measurement=p_meas)


def chsh_value(state, a0, a1, b0, b1):
    def corr(ta, tb):
        A = SparsePauliOp(["Z", "X"], [math.cos(ta), math.sin(ta)])
        B = SparsePauliOp(["Z", "X"], [math.cos(tb), math.sin(tb)])
        return float(np.real(state.expectation_value(B.tensor(A))))
    return corr(a0, b0) + corr(a0, b1) + corr(a1, b0) - corr(a1, b1)


def e05():  # entanglement + CHSH
    c = QuantumCircuit(2); c.h(0); c.cx(0, 1)
    bell = Statevector.from_instruction(c)
    ang = (0, math.pi / 2, math.pi / 4, -math.pi / 4)
    S = chsh_value(bell, *ang)
    ent = float(entropy(partial_trace(bell, [1]), base=2))
    S_prod = chsh_value(Statevector.from_instruction(QuantumCircuit(2)), *ang)
    ok = abs(abs(S) - 2 * math.sqrt(2)) < 1e-9 and abs(ent - 1) < 1e-9 and abs(S_prod) <= 2 + 1e-9
    record("E05", "entanglement: Bell state S_CHSH = 2*sqrt2 > 2, entanglement entropy = 1 bit",
           ok, S_bell=S, S_product_state=S_prod, entanglement_entropy_bits=ent,
           classical_bound=2, tsirelson_bound=2 * math.sqrt(2))


def e06():  # unitarity
    c = QuantumCircuit(3); c.h(0); c.t(0); c.cx(0, 1); c.ry(0.3, 2); c.cz(1, 2); c.s(1)
    U = Operator(c).data
    norm = float(np.linalg.norm(Statevector.from_instruction(c).data))
    record("E06", "gates & circuits: U^dagger U = I, norm preserved",
           np.allclose(U.conj().T @ U, np.eye(8), atol=1e-12) and abs(norm - 1) < 1e-12, norm=norm)


def e07():  # density matrices, channels, T1/T2
    T1, T2 = 50.0, 40.0
    pops, cohs = [], []
    for t in (0, 10, 25, 50, 100):
        g = 1 - math.exp(-t / T1)
        K0 = np.array([[1, 0], [0, math.sqrt(1 - g)]]); K1 = np.array([[0, math.sqrt(g)], [0, 0]])
        r1 = DensityMatrix(np.array([[0, 0], [0, 1]], dtype=complex)).evolve(Kraus([K0, K1]))
        pops.append((t, float(np.real(r1.data[1, 1])), math.exp(-t / T1)))
        lam = 1 - math.exp(-t / T2)
        Kp = [math.sqrt(1 - lam / 2) * np.eye(2), math.sqrt(lam / 2) * np.diag([1, -1])]
        pl = DensityMatrix(0.5 * np.ones((2, 2), dtype=complex)).evolve(Kraus(Kp))
        cohs.append((t, float(np.real(pl.data[0, 1])), 0.5 * math.exp(-t / T2)))
    dep = DensityMatrix(0.5 * np.ones((2, 2), dtype=complex)).evolve(Kraus(depolarizing_error(0.3, 1)))
    purity = float(np.real(dep.purity()))
    ok = all(abs(a - b) < 1e-12 for _, a, b in pops + cohs) and purity < 1
    record("E07", "density matrix, quantum channels, decoherence: T1 decay and T2 dephasing match "
           "analytic exp(-t/T)", ok, T1=T1, T2=T2, population_t_sim_analytic=pops,
           coherence_t_sim_analytic=cohs, depolarizing_purity=purity)


def e08():  # noise vs depth (NISQ)
    p = 0.01
    ch = Kraus(depolarizing_error(p, 1))
    plus = DensityMatrix(0.5 * np.ones((2, 2), dtype=complex)).evolve(ch)
    c_meas = float(np.real(plus.expectation_value(Pauli("X"))))       # measured, not assumed
    rows = []
    for L in (0, 5, 10, 20, 40, 80):
        c = QuantumCircuit(2); c.h(0); c.cx(0, 1)
        rho = DensityMatrix.from_instruction(c); ideal = Statevector.from_instruction(c)
        for _ in range(L):
            rho = rho.evolve(ch, qargs=[0]).evolve(ch, qargs=[1])
        rows.append((L, float(state_fidelity(rho, ideal)), (1 + 3 * c_meas ** (2 * L)) / 4))
    ok = all(abs(f - a) < 1e-9 for _, f, a in rows) and rows[-1][1] < rows[0][1] \
        and abs(c_meas - (1 - p)) < 1e-12
    record("E08", "noise & NISQ depth limit: Bell fidelity decays with noisy layers "
           "(F = (1+3c^(2L))/4, c measured from the channel = 1-p)", ok,
           per_layer_depolarizing_p=p, measured_contraction_c=c_meas, layers_fidelity_analytic=rows)


def e09():  # transpilation
    c = QuantumCircuit(3); c.h(0); c.cx(0, 1); c.cx(1, 2); c.t(2); c.ry(0.4, 1)
    t = transpile(c, basis_gates=["rz", "sx", "x", "cx"], optimization_level=1, seed_transpiler=1)
    record("E09", "transpilation: basis-gate rewrite preserves the unitary (up to global phase)",
           Operator(c).equiv(Operator(t)) and set(t.count_ops()) <= {"rz", "sx", "x", "cx"},
           original_ops=dict(c.count_ops()), transpiled_ops=dict(t.count_ops()),
           original_depth=c.depth(), transpiled_depth=t.depth())


def e10():  # error mitigation: readout calibration inversion
    shots = 20000
    nm = NoiseModel(); nm.add_all_qubit_readout_error(ReadoutError([[0.93, 0.07], [0.10, 0.90]]))
    sim = AerSimulator(noise_model=nm, seed_simulator=3)
    run = lambda circ: sim.run(transpile(circ, sim, seed_transpiler=3), shots=shots).result().get_counts()
    labels = ["00", "01", "10", "11"]
    A = np.zeros((4, 4))
    for j, lab in enumerate(labels):
        c = QuantumCircuit(2, 2)
        for q, b in enumerate(reversed(lab)):
            if b == "1": c.x(q)
        c.measure([0, 1], [0, 1])
        cnt = run(c)
        for i, l2 in enumerate(labels): A[i, j] = cnt.get(l2, 0) / shots
    bell = QuantumCircuit(2, 2); bell.h(0); bell.cx(0, 1); bell.measure([0, 1], [0, 1])
    raw = run(bell); v = np.array([raw.get(l, 0) / shots for l in labels])
    mit = np.clip(np.linalg.solve(A, v), 0, None); mit /= mit.sum()
    zz = lambda p: p[0] - p[1] - p[2] + p[3]
    ok = abs(zz(mit) - 1) < abs(zz(v) - 1) and abs(zz(mit) - 1) < 0.03
    record("E10", "error mitigation: readout calibration-matrix inversion restores <ZZ> toward 1",
           ok, raw_ZZ=float(zz(v)), mitigated_ZZ=float(zz(mit)), ideal_ZZ=1.0,
           forbidden_prob_raw=float(v[1] + v[2]), forbidden_prob_mitigated=float(mit[1] + mit[2]))


def e11():  # teleportation
    theta, phi = 0.9, 1.3
    c = QuantumCircuit(3); c.ry(theta, 0); c.rz(phi, 0)
    c.h(1); c.cx(1, 2); c.cx(0, 1); c.h(0); c.cx(1, 2); c.cz(0, 2)
    bob = partial_trace(Statevector.from_instruction(c), [0, 1])
    one = QuantumCircuit(1); one.ry(theta, 0); one.rz(phi, 0)
    F = float(state_fidelity(bob, Statevector.from_instruction(one)))
    record("E11", "quantum communication: teleportation of an arbitrary qubit (fidelity 1)",
           abs(F - 1) < 1e-9, fidelity=F)


def bb84(n, eve, rng):
    a_bits = rng.integers(0, 2, n); a_bases = rng.integers(0, 2, n); b_bases = rng.integers(0, 2, n)
    bits, bases = a_bits.copy(), a_bases.copy()
    if eve:
        e_b = rng.integers(0, 2, n)
        bits = np.where(e_b == bases, bits, rng.integers(0, 2, n)); bases = e_b
    b_res = np.where(b_bases == bases, bits, rng.integers(0, 2, n))
    sift = a_bases == b_bases
    return float(np.mean(a_bits[sift] != b_res[sift])), int(sift.sum())


def e12():  # QKD
    rng = np.random.default_rng(42)
    q0, _ = bb84(40000, False, rng); q1, ns = bb84(40000, True, rng)
    record("E12", "QKD (BB84): intercept-resend eavesdropper raises QBER from ~0 to ~25%",
           q0 < 0.005 and abs(q1 - 0.25) < 0.02, qber_no_eve=q0, qber_with_eve=q1, sifted_key_bits=ns)


def e13():  # hybrid loop
    def energy(x):
        c = QuantumCircuit(1); c.ry(x[0], 0)
        return float(np.real(Statevector.from_instruction(c).expectation_value(Pauli("Z"))))
    r = minimize(energy, [0.3], method="COBYLA", options={"rhobeg": 0.5, "maxiter": 100})
    record("E13", "hybrid classical-quantum loop: COBYLA drives <Z> to its minimum -1 at theta=pi",
           abs(r.fun + 1) < 1e-4 and abs(abs(r.x[0]) % (2 * math.pi) - math.pi) < 1e-2,
           theta_opt=float(r.x[0]), energy=float(r.fun))


if __name__ == "__main__":
    for fn in (e01, e02, e03, e04, e05, e06, e07, e08, e09, e10, e11, e12, e13):
        fn()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "learning_results.json")
    with open(out, "w") as f:
        json.dump({"all_passed": all(v["passed"] for v in RESULTS.values()),
                   "experiments": RESULTS}, f, indent=2, default=float)
    print(f"\n{sum(v['passed'] for v in RESULTS.values())}/{len(RESULTS)} experiments passed -> {out}")
